@echo off
title Uninstall Driftwave
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
